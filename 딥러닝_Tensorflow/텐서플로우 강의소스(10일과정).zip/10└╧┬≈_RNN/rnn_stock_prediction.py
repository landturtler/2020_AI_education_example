# rnn_stock_prediction.py

import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt

tf.set_random_seed(777)

# parameters
seq_length = 7
data_dim = 5
hidden_dim = 10
output_dim = 1
learning_rate = 0.01
iterations = 500

def MinMaxScaler(data): # normaliztion
    numerator = data - np.min(data,0)
    denominator = np.max(data,0) - np.min(data,0)
    return numerator/(denominator + 1e-7)

# x,y data : Open,High,Low,Volume,Close
xy = np.loadtxt('data-02-stock_daily.csv',delimiter=',')
xy = xy[::-1]   # reverse order (chronically ordered)  # (732,5)

xy = MinMaxScaler(xy)
x = xy
y = xy[:,[-1]]  # Close as label , (732,1)

dataX = []
dataY = []
for i in range(len(y)-seq_length): # 732-7 -> 725
    _x = x[i:i+seq_length]
    _y = y[i+seq_length]  # Next close price
    # print(_x,'->',_y)
    dataX.append(_x)
    dataY.append(_y)

# train/test split
train_size = int(len(dataY)*0.7)    # 725 * 0.7 --> 507 개
test_size = len(dataY) - train_size # 725 - 507 --> 218개

trainX = np.array(dataX[0:train_size])  # 507개
trainY = np.array(dataY[0:train_size])
# print(trainX.shape,trainY.shape) # (507, 7, 5) (507, 1)
testX = np.array(dataX[train_size:len(dataX)])  # 218개
testY = np.array(dataY[train_size:len(dataY)])
# print(testX.shape,testY.shape)   # (218, 7, 5) (218, 1)

X = tf.placeholder(tf.float32,[None,seq_length,data_dim]) # (?,7,5)
Y = tf.placeholder(tf.float32,[None,1])

# build a LSTM network
cell = tf.contrib.rnn.BasicLSTMCell(num_units=hidden_dim,state_is_tuple=True,\
                                    activation=tf.tanh)
# initial_state = cell.zero_state(batch_size,tf.float32)
outputs,_states = tf.nn.dynamic_rnn(cell,X , dtype=tf.float32)
# print(outputs) # (?,7,10)
# print(_states) # (?,10)

# FC layers
Y_pred = tf.contrib.layers.fully_connected(outputs[:,-1],output_dim,\
                                           activation_fn=None)
# print(Y_pred) # (?,1)

# cost/loss
loss = tf.reduce_sum(tf.square(Y_pred - Y)) # sum of the squares

# optimizer
optimizer = tf.train.AdamOptimizer(learning_rate=learning_rate)
train = optimizer.minimize(loss)

# RMSE( root-mean-square error ) : 평균 제곱 근 오차
# 평균 제곱근편차(RMSD) 또는 평균 제곱근오차(RMSE)는 추정값 또는 모델이 예측한 값과
# 실제 환경에서 관찰되는 값의 차이를 다룰 때 흔히 사용하는 측도이다.
# 정밀도를 표현하는데 적합하다.
targets = tf.placeholder(tf.float32,[None,1])  # 답(Y)
predictions = tf.placeholder(tf.float32,[None,1]) # 예측 값
rmse = tf.sqrt(tf.reduce_mean(tf.square(targets-predictions)))

# start trainnig
with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())

    # Training step
    for i in range(500): # 500
        l,_ = sess.run([loss,train],feed_dict={X:trainX,Y:trainY})
        print("[step:{}] loss:{}".format(i,l))

    # Test step
    test_predict = sess.run(Y_pred,feed_dict={X:testX})
    rmse_val = sess.run(rmse,feed_dict={targets:testY,predictions:test_predict})
    print('RMSE: {}'.format(rmse_val))

    # predict 시각화
    plt.plot(testY)
    plt.plot(test_predict)
    plt.xlabel("Time Period")
    plt.ylabel("Stock Price")
    plt.show()




