# rnn_long_char.py
# long sentence 입력

import tensorflow as tf
import numpy as np

tf.set_random_seed(777)

sentence = ("if you want to build a ship, don't drum up people together to "
            "collect wood and don't assign them tasks and work, but rather "
            "teach them to long for the endless immensity of the sea.")
# sentence = "내가 그린 구름 그림은 잘 그린 구름 그림이고 네가 그린 구름 그림은 잘 못 그린 구름 그림이다"

# sentence = ("월급으로 임금을 주는 사업장의 최저임금 위반 여부를 따질 때는"
# 	    "최저임금 산입범위에 들어가는 임금 총액을 월 노동시간으로 나눠 "
# 	    "최저임금과 비교할 '가상 시급'을 산출해야 하는데 이때 적용하는 "
# 	    "월 노동시간이 최저임금 산정 기준 시간이다.")

# print(len(sentence))  # 180
# char_set = sorted(set(sentence))  # 25개 문자
char_set = list(set(sentence))  # 25개 문자
char_dic = {w:i for i,w in enumerate(char_set)}
print(len(char_set),char_set)
print(char_dic)

# hyper parameters
data_dim = len(char_set) # 25
hidden_size = len(char_set) # 25
num_classes = len(char_set) # 25
sequence_length = 10  # 임의로 설정

learning_rate = 0.1

# x_data, y_data, X,Y 입력변수
dataX = []
dataY = []
for i in range(len(sentence) - sequence_length):  # 180 - 10 --> 170
    x_str = sentence[i:i+sequence_length]       # "if you wan"
    y_str = sentence[i+1:i+sequence_length + 1] # "f you want"
    print(i,x_str,'->',y_str)

    x = [char_dic[c] for c in x_str]
    y = [char_dic[c] for c in y_str]
    # print('x:',x)
    # print('y:',y)

    dataX.append(x)
    dataY.append(y)

# print(dataX) # (170,10)
# print(dataY) # (170,10)

batch_size = len(dataX) # 170

X = tf.placeholder(tf.int32,[None,sequence_length]) # (?,10)
Y = tf.placeholder(tf.int32,[None,sequence_length]) # (?,10)

X_one_hot = tf.one_hot(X,num_classes)
# print(X_one_hot) # (?,10,25)

# Stacked RNN :  2 RNN layer
cell = tf.contrib.rnn.BasicLSTMCell(hidden_size,state_is_tuple =True)
multi_cells = tf.contrib.rnn.MultiRNNCell([cell]*2,state_is_tuple =True)
# initial_state = cell.zero_state(batch_size,tf.float32)
outputs,_states = tf.nn.dynamic_rnn(multi_cells,X_one_hot,dtype=tf.float32)
# print(outputs) # (?,10,25)
# print(multi_cells)

# def lstm_cell():
#     cell = tf.contrib.rnn.BasicLSTMCell(hidden_size, state_is_tuple=True)
#     return cell
#
# multi_cells = tf.contrib.rnn.MultiRNNCell([lstm_cell() for _ in range(2)],state_is_tuple =True)
# outputs,_states = tf.nn.dynamic_rnn(multi_cells,X_one_hot,dtype=tf.float32)
# print(multi_cells)

# FC layer
X_for_fc = tf.reshape(outputs,[-1,hidden_size]) # (?,25)
# print(X_for_fc) # (?,25) * (25,25) = (?,25)
outputs = tf.contrib.layers.fully_connected(inputs=X_for_fc,num_outputs= \
                                            num_classes,activation_fn=None)
print(outputs) # (?,25)

# sequence_loss
outputs = tf.reshape(outputs,[batch_size,sequence_length,num_classes]) # (170,10,25)
weights = tf.ones([batch_size,sequence_length]) # (170,10)
sequence_loss = tf.contrib.seq2seq.sequence_loss(logits=outputs,targets=Y,\
                                                 weights=weights )
loss = tf.reduce_mean(sequence_loss)

train = tf.train.AdamOptimizer(learning_rate=learning_rate).minimize(loss)

prediction =tf.argmax(outputs,axis=2) # (170,10,25) -> (170,10)

# start training
with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())
    for i in range(1500):
        l,_ = sess.run([loss,train],feed_dict={X:dataX,Y:dataY})
        results = sess.run(prediction,feed_dict={X:dataX}) # (170,10)

        for j,index in enumerate(results):
            print(i,j,l,''.join([char_set[t] for t in index]))


    # all data
    results = sess.run(prediction, feed_dict={X: dataX})  # (170,10)
    for j,index in enumerate(results):
        if j == 0:
            print(''.join([char_set[t] for t in index]),end='')
        else :
            print(char_set[index[-1]],end='')

        # t you want to build a ship, don't drum up people together to
        # collect wood and don't assign them tasks and work, but rather
        # teach them to long for the endless immensity of the sea.





