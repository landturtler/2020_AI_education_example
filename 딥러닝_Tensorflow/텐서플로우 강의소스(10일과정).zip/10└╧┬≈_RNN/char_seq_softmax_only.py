# char_seq_softmax_only.py
# softmax 만 사용

import tensorflow as tf
import numpy as np

tf.set_random_seed(777)

sample =" if you want you"

idx2char = list(set(sample))
char2idx = {c:i for i,c in enumerate(idx2char)}

# hyper parameters
dic_size = len(char2idx)     # 10
hidden_size = len(char2idx)  # 10
num_classes = len(char2idx)  # 10
batch_size = 1
sequence_length = len(sample) - 1 # 15
learning_rate = 0.1

# x_data, y_data, X,Y 입력변수
sample_idx = [char2idx[c] for c in sample] # char to index
x_data = [sample_idx[:-1]] # (1,15)
y_data = [sample_idx[1:]]  # (1,15)

X = tf.placeholder(tf.int32,[None,sequence_length]) # (?,15)
Y = tf.placeholder(tf.int32,[None,sequence_length]) # (?,15)

x_one_hot = tf.one_hot(X,num_classes)  # (?,15,10)

x_for_softmax = tf.reshape(x_one_hot,[-1,hidden_size]) # (?,10)

# softmax layer : RNN layer 대신사용
# (?,10) * (10,10) = (?,10)
W = tf.Variable(tf.random_normal([hidden_size,num_classes]),name='weight')
b = tf.Variable(tf.random_normal([num_classes]),name='bias')
outputs = tf.matmul(x_for_softmax,W)+b


# sequence_loss
outputs = tf.reshape(outputs,[batch_size,sequence_length,num_classes]) # (1,15,10)
weights = tf.ones([batch_size,sequence_length]) # (1,15)
sequence_loss = tf.contrib.seq2seq.sequence_loss(logits=outputs,targets=Y,\
                                                 weights=weights )
loss = tf.reduce_mean(sequence_loss)

train = tf.train.AdamOptimizer(learning_rate=learning_rate).minimize(loss)

prediction =tf.argmax(outputs,axis=2) # (1,15)

# start training
with tf.Session() as sess:  # sess = tf.Session()--> sess.close()
    sess.run(tf.global_variables_initializer())
    for i in range(3000):
        l,_ = sess.run([loss,train],feed_dict={X:x_data,Y:y_data})
        result =sess.run(prediction,feed_dict={X:x_data})
        print(i,"loss:",l,"prediction: ",result,"true Y:",y_data)

        # print char using dic
        # np.squeeze() : 차원을 축소하는 함수, [[]] --> []
        # expand_dims() : 차원을 늘리는 함수
        result_str = [idx2char[c] for c in np.squeeze(result)] #
        print("\tPrediction str:",''.join(result_str))         # if you want you





