# char_seq_rnn.py
# size -> 자동으로 처리

import tensorflow as tf
import numpy as np

tf.set_random_seed(777)

sample =" if you want you"

# idx2char = list(set(sample))
idx2char = sorted(set(sample))
# print(idx2char) # ['y', 'w', 't', 'o', ' ', 'i', 'f', 'u', 'n', 'a']
char2idx = {c:i for i,c in enumerate(idx2char)}
# print(char2idx) # {'i': 5, 'f': 6, 'n': 8, ' ': 4, 'y': 0, 'a': 9, 'w': 1, 't': 2, 'u': 7, 'o': 3}

# hyper parameters
dic_size = len(char2idx)     # 10
hidden_size = len(char2idx)  # 10
num_classes = len(char2idx)  # 10
batch_size = 1
sequence_length = len(sample) - 1 # 15
learning_rate = 0.1

# x_data, y_data, X,Y 입력변수
sample_idx = [char2idx[c] for c in sample] # charbto index
x_data = [sample_idx[:-1]] # (1,15)
y_data = [sample_idx[1:]]  # (1,15)
# print(x_data) # [[0, 3, 2, 0, 9, 5, 7, 0, 8, 1, 4, 6, 0, 9, 5]]
# print(y_data) # [[3, 2, 0, 9, 5, 7, 0, 8, 1, 4, 6, 0, 9, 5, 7]]

X = tf.placeholder(tf.int32,[None,sequence_length]) # (?,15)
Y = tf.placeholder(tf.int32,[None,sequence_length]) # (?,15)

x_one_hot = tf.one_hot(X,num_classes)  # 1 -> 0,1,0,0,0,0,0,0,0,0
# print(x_one_hot)  # (?, 15, 10)

# LSTM cell, RNN
cell = tf.contrib.rnn.BasicLSTMCell(num_units=hidden_size,state_is_tuple=True)
initial_state = cell.zero_state(batch_size,tf.float32)
outputs,_states = tf.nn.dynamic_rnn(cell,x_one_hot ,initial_state= \
                      initial_state, dtype=tf.float32)
# print(outputs) # (1,15,10)

# FC layer
X_for_fc = tf.reshape(outputs,[-1,hidden_size]) # (15,10)
# print(X_for_fc) # (15,10) * (10,10) = (15,10)
outputs = tf.contrib.layers.fully_connected(inputs=X_for_fc,num_outputs= \
                                            num_classes,activation_fn=None)
# print(outputs) # (15,10)

# sequence_loss
outputs = tf.reshape(outputs,[batch_size,sequence_length,num_classes]) # (1,15,10)
weights = tf.ones([batch_size,sequence_length]) # (1,15)
sequence_loss = tf.contrib.seq2seq.sequence_loss(logits=outputs,targets=Y,\
                                                 weights=weights )
loss = tf.reduce_mean(sequence_loss)

train = tf.train.AdamOptimizer(learning_rate=learning_rate).minimize(loss)

prediction =tf.argmax(outputs,axis=2) # (1,15)

# start training
with tf.Session() as sess:  # sess = tf.Session()--> sess.close()
    sess.run(tf.global_variables_initializer())
    for i in range(50):
        l,_ = sess.run([loss,train],feed_dict={X:x_data,Y:y_data})
        result =sess.run(prediction,feed_dict={X:x_data})
        print(i,"loss:",l,"prediction: ",result,"true Y:",y_data)

        # print char using dic
        # np.squeeze() : 차원을 축소하는 함수, [[]] --> []
        # expand_dims() : 차원을 늘리는 함수
        result_str = [idx2char[c] for c in np.squeeze(result)] #
        print("\tPrediction str:",''.join(result_str))         # if you want you



