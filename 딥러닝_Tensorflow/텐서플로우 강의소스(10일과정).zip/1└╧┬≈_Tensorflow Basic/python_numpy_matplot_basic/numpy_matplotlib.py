import numpy as np
import matplotlib.pyplot as plt

def draw_sin_graph() :
    x = np.arange(0,6,0.1) # 0 에서 6 까지 0.1 간격으로 생성
    y = np.sin(x)

    plt.plot(x,y)
    plt.show()

# draw_sin_graph()
def draw_sin_cos_graph() :
    x = np.arange(0,6, 0.1)  # 0 에서 6 까지 0.1 간격으로 생성
    y1 = np.sin(x)
    y2 = np.cos(x)

    # 그래프 출력
    plt.plot(x, y1, label = "sin")
    plt.plot(x, y2, linestyle = "--", label = "cos")
    plt.xlabel("x") # x축 이름
    plt.ylabel("y") # y축 이름
    plt.title('sin & cos')
    plt.legend()
    plt.show()

draw_sin_cos_graph()

def draw_image() :
    from matplotlib.image import imread
    img = imread('test.png') # 이미지 읽어오기

    plt.imshow(img)
    plt.show()

# draw_image()

if __name__ == '__main__' : # C언어 main()함수와 같은 역할
    draw_image()