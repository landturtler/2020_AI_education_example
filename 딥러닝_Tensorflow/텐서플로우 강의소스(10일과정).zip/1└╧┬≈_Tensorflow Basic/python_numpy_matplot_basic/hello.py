import tensorflow as tf
print(tf.__version__)

# 단축키 암기
# CTRL + / : 주석문 설정/해제
# Tab : 들여쓰기(Indent)
# Shift + Tab : 들여쓰기 해제(Unndent)
# Shift + F10 : Run
# 

a, b = 7 ,3
print(a,b)

# 산술연산 : + - * / ** // %
print(a + b)
print(a - b)
print(a * b)
print(a / b)  # 나눗셈 실수
print(a ** b) # 지수
print(a // b) # 나눗셈 정수 몫
print(a % b)  # 나머지

# 관계연산자 : > >= < <= == !=
print(a > b)
print(a < b)
print(a >= b)
print(a <= b)
print(a == b)
print(a != b)

# 자료형
# list : [ ] , 요소값 변경이 가능
a = [1,3,5,7]
print(a[0],a[1],a[2],a[-1]) # indexing
print(a[1:3])  # slicing
a[0] = 10
a.append(99)
print(a)

# tuple : ( ), 요소값 변경이 불가능
a = (1,3,5,7)
print(a[0],a[1],a[2],a[-1]) # indexing
print(a[1:3])  # slicing
# a[0] = 10  # Error
# a.append(99)

# dictionary : { }
d = {'name': 'kildong', 'age':40}
print(d['name'],d['age'])

# 반복문
s = ''
for i in range(1,10) : # 1~9
    s += str(i) + ' '
    print(s)
#
# 함수
def func_1(a,b):
    c = a + b
    return c

ret= func_1(10,20)
print(ret)

def hello() :
    print('Hello Pycharm')
    mystr = 'Hello'
    print(mystr)
    a = 10
    b = 20
    c = a * b
    print(c)

hello()